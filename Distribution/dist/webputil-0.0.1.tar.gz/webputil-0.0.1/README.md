# webpUtil
## General one-way .webp to .png or .gif conversion utility/

This simple gui-based utility allows a user to convert annoyingly unsupported .webp images to .png or .gif with ease.
Benefits include the ability to pretend the .webp file extension never existed with the side effect of using more memory when assembling awesome powerpoint presentations.
Enjoy! :^)

Assembled during the Fall Semester of 2024.